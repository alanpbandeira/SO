from app import App
import tkinter as tk


root = tk.Tk()
my_app = App(master=root)
